// Load the AWS SDK for Node.js
var aws = require('aws-sdk');

// Create a new SES object in ap-south-1 region
var ses = new aws.SES({region: 'us-east-1'});

exports.handler = (event, context, callback) => {
       var email_details = event.Records[0].Sns.Message;
       var msgJson = JSON.parse(email_details);

     var params = {
        Destination: {
        //    ToAddresses: ["thomas.ge@northeastern.edu"]
           ToAddresses: [msgJson.to_email1, msgJson.to_email2]

        },
        Message: {
            Body: {
                Text: { Data: msgJson.body //event.body
                    
                }
                
            },
            
            Subject: { Data: msgJson.subject
                
            }
        },
        //Source: event.from_email
        Source: msgJson.from_email
    };

    
     ses.sendEmail(params, function (err, data) {
        callback(null, {err: err, data: data});
        if (err) {
            console.log('This is error log');
            console.log(err);
            context.fail(err);
        } else {
            console.log('This is success log');
            console.log(data);
            context.succeed(event);
        }
    });
    return context.logStreamName;
};
