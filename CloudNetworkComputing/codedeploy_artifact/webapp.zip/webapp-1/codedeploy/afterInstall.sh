#!/bin/sh
sudo chown -R ubuntu:ubuntu /home/ubuntu/webapp