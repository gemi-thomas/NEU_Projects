#!/bin/sh
cd /home/ubuntu
pwd
sudo rm -rf webapp/*